//Made by ltsRoy, for GitHub.

chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    const url = new URL(details.url);
    if (url.hostname === 'www.reddit.com') {
      url.hostname = 'old.reddit.com';
      return { redirectUrl: url.href };
    }
  },
  { urls: ["*://*.reddit.com/*"], types: ["main_frame"] },
  ["blocking"]
);

